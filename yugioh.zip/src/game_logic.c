#include <stdio.h>
#include <string.h>
#include "game_logic.h"

int playerLifePoints = 8000;
int opponentLifePoints = 8000;

void deductLifePoints(int *lifePoints, int amount) {
    *lifePoints -= amount;
    if (*lifePoints < 0) *lifePoints = 0;
}

void attack(int attackPoints, int *opponentLifePoints) {
    deductLifePoints(opponentLifePoints, attackPoints);
}

int checkExodia(const char *hand[], int handSize) {
    int exodiaCount = 0;
    const char *exodiaPieces[5] = {
        "Exodia the Forbidden One",
        "Left Arm of the Forbidden One",
        "Right Arm of the Forbidden One",
        "Left Leg of the Forbidden One",
        "Right Leg of the Forbidden One"
    };
    for (int i = 0; i < handSize; i++) {
        for (int j = 0; j < 5; j++) {
            if (hand[i] != NULL && strcmp(hand[i], exodiaPieces[j]) == 0) {
                exodiaCount++;
                break;
            }
        }
    }
    return exodiaCount == 5;
}

