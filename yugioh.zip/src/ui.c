#include <stdio.h>
#include "ui.h"
#include "types.h"
#include "game_functions.h"

void drawButton(int x, int y, int width, int height, u32 color, const char *text) {
    drawRectangle(x, y, width, height, color);
    printf("\x1b[%d;%dH%s", (y / 8) + 1, (x / 4) + 1, text);
}

