#include <stdio.h>
#include <ogcsys.h>       // Include the header for u32 definition
#include "game_logic.h"   // Include the header file where game logic functions and variables are declared
#include "console.h"      // Include the header file where initializeConsole and displayLifePoints are declared
#include <wiiuse/wpad.h>  // Include the header file for Wii controllers
#include "game_functions.h"
#include "ui.h"           // Include the header file where drawButton is declared

// Define the player's hand and its size
const char *playerHand[] = {
    "Exodia the Forbidden One", 
    "Left Arm of the Forbidden One", 
    "Right Arm of the Forbidden One", 
    "Left Leg of the Forbidden One", 
    "Right Leg of the Forbidden One"
};
#define HAND_SIZE 5

int main() {
    initializeConsole(); // Initialize the console

    while (1) {
        WPAD_ScanPads(); // Scan the Wii controllers
        u32 pressed = WPAD_ButtonsDown(0); // Get the buttons pressed

        if (pressed & WPAD_BUTTON_HOME) break; // If the Home button is pressed, exit the loop

        if (pressed & WPAD_BUTTON_A) attack(500, &opponentLifePoints); // If the A button is pressed, attack the opponent
        if (pressed & WPAD_BUTTON_B) attack(500, &playerLifePoints); // If the B button is pressed, attack the player

        printf("\x1b[2;0HPress A to attack opponent, B to attack player."); // Print instructions on the console
        displayLifePoints(); // Display life points on the console

        if (checkExodia(playerHand, HAND_SIZE)) { // Check if the player has Exodia
            printf("\x1b[12;0HExodia Obliterate! You win!"); // Print victory message on the console
            break; // Exit the loop
        }

        drawButton(20, 20, 100, 50, 0xFFFF00, "Button"); // Draw a sample button

        VIDEO_WaitVSync(); // Wait for the vertical synchronization
    }

    return 0; // Return success
}

