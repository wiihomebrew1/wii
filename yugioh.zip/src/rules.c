#include <stdio.h>
#include "rules.h"

void ShowRules() {
    // Rules display function implementation
}
