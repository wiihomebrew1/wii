#ifndef GAME_LOGIC_H
#define GAME_LOGIC_H

void deductLifePoints(int *lifePoints, int amount);
void attack(int attackPoints, int *opponentLifePoints);
int checkExodia(const char *hand[], int handSize);

extern int playerLifePoints;
extern int opponentLifePoints;

#endif // GAME_LOGIC_H

