#ifndef GAME_FUNCTIONS_H
#define GAME_FUNCTIONS_H

#include <ogcsys.h>

void attack(int damage, int *lifePoints);
void displayLifePoints();
int checkExodia(const char *hand[], int handSize);
void drawRectangle(int x, int y, int width, int height, u32 color);

#endif // GAME_FUNCTIONS_H

