#ifndef UI_H
#define UI_H

#include "types.h" // Include the header file where u32 is defined

// Function declaration for drawing a button
void drawButton(int x, int y, int width, int height, u32 color, const char *text);

#endif /* UI_H */

