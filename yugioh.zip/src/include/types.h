#ifndef TYPES_H
#define TYPES_H

// Define the u32 type
typedef unsigned int u32;

#endif /* TYPES_H */
