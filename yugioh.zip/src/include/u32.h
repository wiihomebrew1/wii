#ifndef U32_H
#define U32_H

// Define u32 type if not already defined
typedef unsigned int u32;

#endif /* U32_H */
