#ifndef CONSOLE_H
#define CONSOLE_H

void initializeConsole();
void drawRectangle(int x, int y, int width, int height, u32 color);

#endif // CONSOLE_H

