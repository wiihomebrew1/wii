#ifndef RULES_H
#define RULES_H

void ShowRules();

#endif /* RULES_H */
